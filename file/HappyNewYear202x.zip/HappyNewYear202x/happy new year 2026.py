import random
from pyfiglet import Figlet
from termcolor import colored
fonts = ['slant','banner3-D','big','block',
#         'bubble','digital','random','isometricl',
         'mini','small','starwas']
colors = ['grey','green','yellow','blue',
          'orange','white']
F = Figlet(font=random.choice(fonts))
print(colored(F.renderText("Happy New Year 2027"),
              random.choice(colors)))

3