from pyfiglet import Figlet
from termcolor import colored
from colorama import init
import random

init()  # <<< BẮT BUỘC TRÊN WINDOWS

fonts = ['slant', 'banner3-D', 'big', 'block', 'mini', 'small', 'straws']
colors = ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']

f = Figlet(font=random.choice(fonts))
print(colored(
    f.renderText("Happy New Year 2026"),
    random.choice(colors)))
